import os
import psycopg
from dotenv import load_dotenv

load_dotenv()

def get_connection_uri():
    pg_user = os.getenv('PGUSER')
    pg_host = os.getenv('PGHOST')
    pg_database = os.getenv('PGDATABASE')
    token_path = os.path.join(os.path.dirname(__file__), 'aad_token.txt')
    if not (pg_user and pg_host and pg_database):
        raise Exception('Missing PGUSER, PGHOST, or PGDATABASE environment variable')
    if not os.path.exists(token_path):
        raise Exception(f"AAD token file not found: {token_path}")
    with open(token_path, 'r') as f:
        token = f.read().strip().replace('\n', '')
    from urllib.parse import quote
    encoded_user = quote(pg_user)
    return f"postgresql://{encoded_user}:{token}@{pg_host}:5432/{pg_database}?sslmode=require"

def create_extensions():
    uri = get_connection_uri()
    print(f"[EXT] Connecting to: {uri.split('@')[1].split('?')[0]}")  # Show host/db only, not token
    try:
        with psycopg.connect(uri) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT current_database(), current_user;")
                db, user = cur.fetchone()
                print(f"[EXT] Connected to database: {db} as user: {user}")
                # Try to create vector extension
                try:
                    cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                    conn.commit()
                    print("[EXT] Vector extension created or already exists.")
                except Exception as ext_e:
                    print(f"[EXT] Error creating vector extension: {ext_e}")
                # Try to create pg_diskann extension
                try:
                    cur.execute("CREATE EXTENSION IF NOT EXISTS pg_diskann;")
                    conn.commit()
                    print("[EXT] pg_diskann extension created or already exists.")
                except Exception as ext_e:
                    print(f"[EXT] Error creating pg_diskann extension: {ext_e}")
    except Exception as e:
        print(f"[EXT] Connection or SQL error: {e}")

def create_tables():
    uri = get_connection_uri()
    print("[TABLE] Creating conversation tables if not exists...")
    create_conversations_table = '''
    CREATE TABLE IF NOT EXISTS conversation_sessions (
        session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        session_name VARCHAR(255),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        metadata JSONB DEFAULT '{}'::jsonb
    );
    '''
    create_messages_table = '''
    CREATE TABLE IF NOT EXISTS conversation_messages (
        message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        session_id UUID REFERENCES conversation_sessions(session_id) ON DELETE CASCADE,
        message_order INTEGER,
        role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'agent', 'system')),
        content TEXT NOT NULL,
        content_hash VARCHAR(64) NOT NULL,
        embedding VECTOR(1536),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        metadata JSONB DEFAULT '{}'::jsonb,
        UNIQUE(session_id, message_order)
    );
    '''
    create_indexes = [
        "CREATE INDEX IF NOT EXISTS idx_messages_content_hash ON conversation_messages(content_hash);",
        "CREATE INDEX IF NOT EXISTS idx_messages_role ON conversation_messages(role);",
        "CREATE INDEX IF NOT EXISTS idx_messages_created_at ON conversation_messages(created_at);",
        "CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON conversation_sessions(created_at);"
    ]
    diskann_index = "CREATE INDEX IF NOT EXISTS idx_messages_embedding_diskann ON conversation_messages USING diskann (embedding vector_cosine_ops);"
    try:
        with psycopg.connect(uri) as conn:
            with conn.cursor() as cur:
                cur.execute(create_conversations_table)
                cur.execute(create_messages_table)
                for idx_sql in create_indexes:
                    try:
                        cur.execute(idx_sql)
                        print(f"[INDEX] Created or exists: {idx_sql.split('ON')[0].strip()}")
                    except Exception as idx_e:
                        print(f"[INDEX] Error: {idx_e}")
                # Try DiskANN index
                try:
                    cur.execute(diskann_index)
                    print("[INDEX] DiskANN vector similarity index created or already exists.")
                except Exception as diskann_e:
                    print(f"[INDEX] Error creating DiskANN index: {diskann_e}")
                conn.commit()
        print("[TABLE] Tables and indexes created or already exist.")
    except Exception as e:
        print(f"[TABLE] Error creating tables or indexes: {e}")

if __name__ == "__main__":
    create_extensions()
    create_tables()
