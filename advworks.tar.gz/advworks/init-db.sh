#!/bin/bash
# Load environment variables from .env file
if [ -f /mcp/.env ]; then
	export $(grep -v '^#' /mcp/.env | xargs)
fi


echo "Obtained AAD access token."
# Retrieve AAD access token from /mcp/aad_token.txt as a single line
if [ -f /mcp/aad_token.txt ]; then
	export PGPASSWORD=$(tr -d '\n' < /mcp/aad_token.txt)
else
	echo "/mcp/aad_token.txt not found!" >&2
	exit 1
fi


# Create database if it does not exist (optional, requires proper permissions)
psql -h "$PGHOST" -U "$PGUSER" -d postgres -c "CREATE DATABASE advworks;" || true

# Restore the SQL file using AAD credentials
psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -v ON_ERROR_STOP=1 < /mcp/advworks/advworks.sql
